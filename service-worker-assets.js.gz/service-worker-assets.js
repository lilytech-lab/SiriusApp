self.assetsManifest = {
  "version": "xW8EJ7lP",
  "assets": [
    {
      "hash": "sha256-Zy2lSWHbkuYxvWeJEWM/ghIdq5I/PcezQeq3W4iplk4=",
      "url": "FW/Sirius.bin"
    },
    {
      "hash": "sha256-kBmVfU2BqUZUT8HPz7NUnkObDjxYKbSWXF5q33paHM0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-VHJcGholtUHNobadpTrhyE/VCi90X4p12vYD83bzI04=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-yAPYxO0UcV5YvjmoVWBh8O+tMbwO9AMZv1RMPdpxE0Q=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-+g2yxtBreIwiH5ySMgvg0O2RiV4DhANP5A1UyKXD+bQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.6pjd1amwtp.wasm"
    },
    {
      "hash": "sha256-42tAs9me8ILik4YHKI67I107QWt5ZkaNQf9Suep8g8k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.172gdatzx1.wasm"
    },
    {
      "hash": "sha256-VvHn+8B02a0Y2xw+/fR9AxJj9cpU2Ohj/t5VBCy6x98=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.mou06c2n8o.wasm"
    },
    {
      "hash": "sha256-/e+U6lbmV9ouEnLrnEzzDup5jtPhEXg4JTDVwY8n1Gk=",
      "url": "_framework/Microsoft.AspNetCore.Components.hjgtzpbpn5.wasm"
    },
    {
      "hash": "sha256-TRP7en/tYrB0OHj3n5BVZ5BQH3VTIuLi7/i+WeKRXyM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h3x7gkd3wi.wasm"
    },
    {
      "hash": "sha256-OjISDzBleMVRyG6rOCMR1WjrrnGHVnlAEGfRtLYXksQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.awfv43uy1f.wasm"
    },
    {
      "hash": "sha256-SetdHnoubSXEfLfgohBpm7QWFpANyybYdHUQHXJmcGQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.zdophn6obr.wasm"
    },
    {
      "hash": "sha256-4NYsL7TJR9sNW0CZ9EZeSw767EeSPOJtdwR2x19l8eo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.sd3rtkogkr.wasm"
    },
    {
      "hash": "sha256-FLbHGpks/qUdpolOZxXwNFFHSZ2+KaN0l03L22jlZOw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.sa5hpai13s.wasm"
    },
    {
      "hash": "sha256-wcQOgA7/nY0MbDORe9thiJBPDhAoiK70e413vNQgu6k=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.x4xw9b6luq.wasm"
    },
    {
      "hash": "sha256-YjAEWNu9hHIkybrnQfBzzsesPRr7ew/FVVkpt0vMyjc=",
      "url": "_framework/Microsoft.Extensions.Localization.ywcwjpftt0.wasm"
    },
    {
      "hash": "sha256-sJqpG/RCGV21wJcp+Ca7vgs8N+Bnsy8prLw0oPmmV8Y=",
      "url": "_framework/Microsoft.Extensions.Logging.0wppuax7wd.wasm"
    },
    {
      "hash": "sha256-ll433HQFxUSAMfYHy8r2upIV2LY/z6EvOaPHrB5DfLo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ub854xon2j.wasm"
    },
    {
      "hash": "sha256-yD8Pd4Px7n1i/tM2ey8Pwl4ZU/22M7Ck8Tbpp188L94=",
      "url": "_framework/Microsoft.Extensions.Options.0iglx6m0j5.wasm"
    },
    {
      "hash": "sha256-wPHyXmdrduba3eHx418PJMQVjpA/rpfj5v5LIH2suHI=",
      "url": "_framework/Microsoft.Extensions.Primitives.sxwmyjz82q.wasm"
    },
    {
      "hash": "sha256-IbbB/XtjYWT/H76RKR7XCkmdE5Vo4ubHSshoYiq9Od0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.jnpc95ilb1.wasm"
    },
    {
      "hash": "sha256-zndEC1k5kL0bOaWTl5Knui7U+GmLvJ/zt4fMi0OZJSI=",
      "url": "_framework/Microsoft.JSInterop.yru4vxilhj.wasm"
    },
    {
      "hash": "sha256-BUvDoU6n5ZXHC2HxP0QiE/bS9aAIezIrXV9NUzX94t0=",
      "url": "_framework/MudBlazor.frmfksdlgy.wasm"
    },
    {
      "hash": "sha256-BHZXow9LiDBjgzpHccGTgZ0VZt33t6kUlYSxQtkyDEg=",
      "url": "_framework/SiriusApp.siazqfa7y2.wasm"
    },
    {
      "hash": "sha256-drjhC4USIrhst8ifJk+6/XFAXPcCbgLxIFFHRd4iEQI=",
      "url": "_framework/System.Collections.Concurrent.yd0ejn18z2.wasm"
    },
    {
      "hash": "sha256-Z8NMTHlNoUKqmuPg92DM9JlpdGUHKqsGJ5YKK7+M6Z4=",
      "url": "_framework/System.Collections.Immutable.lxe8j32tvb.wasm"
    },
    {
      "hash": "sha256-SWSgxQLnfrvU/rpI4GC7gGu7amaZFe9DuoVp93MZNGU=",
      "url": "_framework/System.Collections.fubjxmkbkv.wasm"
    },
    {
      "hash": "sha256-iLB/v5ymsBx034mmns4x2J284v/yxNXikHUL6Ts7BhI=",
      "url": "_framework/System.ComponentModel.0aycg6tn4n.wasm"
    },
    {
      "hash": "sha256-H6jYUiE6zVnFHXB64jPcMxEynowTZnfbg79orGFchEc=",
      "url": "_framework/System.ComponentModel.Annotations.57ijdqqwo4.wasm"
    },
    {
      "hash": "sha256-sh1SKew4Zhhh5EB0EgGfkzg9HtiyBxV28r8+RYe4r0A=",
      "url": "_framework/System.ComponentModel.Primitives.qeiam75w9o.wasm"
    },
    {
      "hash": "sha256-XCScAYJb/mouERSz3R1TR2t7TZIOkfkSE6p62meMkkk=",
      "url": "_framework/System.Console.c0l4pqsz3m.wasm"
    },
    {
      "hash": "sha256-c3VlUVbhJGhrZz04H7zAIWWJdovcHPNW/5lvp2gsMz8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.rumrlhzi38.wasm"
    },
    {
      "hash": "sha256-EWhxA7J9ryvoU3icCZgM2vfR/mEM2EZLLcxqJhr72CQ=",
      "url": "_framework/System.IO.Pipelines.vghmabkwgd.wasm"
    },
    {
      "hash": "sha256-1C0C3PoJRzYHH4AOPZ6SC4ZCJm9xwWp2Pb5nL+Ivj8o=",
      "url": "_framework/System.Linq.09hu3qrhig.wasm"
    },
    {
      "hash": "sha256-XFgoBn9E+y4bEqOJza+/DBkwkZcSEmJbc2fkltldyOs=",
      "url": "_framework/System.Linq.Expressions.g32rtyx0jg.wasm"
    },
    {
      "hash": "sha256-LVi0Df7VkwRYqKmM3C+vPG4Jdm3+wn4SrQVtsmFTxVY=",
      "url": "_framework/System.Memory.x3ak8osz9i.wasm"
    },
    {
      "hash": "sha256-g82d/N0NZlmKdVySGQ/0Aw59wKoqxsoD0rk0RrzsW2E=",
      "url": "_framework/System.Net.Http.p9aawsdob2.wasm"
    },
    {
      "hash": "sha256-3Jn/F0bxGTzq4loeRUSO0Idash12lXdTsQc6V+fmBfY=",
      "url": "_framework/System.Net.Primitives.gl2sy2s492.wasm"
    },
    {
      "hash": "sha256-cVIgPJfzgN3tmOUqoxHnGx/IoXol+6nC/FQ+8olMH9Y=",
      "url": "_framework/System.Private.CoreLib.f0o08bmfwv.wasm"
    },
    {
      "hash": "sha256-D6W5SIoniK47iQxunkflV3gje5cG0nXmtjVFYvJqqvE=",
      "url": "_framework/System.Private.Uri.zfpx2dh4fr.wasm"
    },
    {
      "hash": "sha256-pg1DdfEus8MgtvuevXJW7tX0CHVfSV+Zu9N/Xlo6NMY=",
      "url": "_framework/System.Runtime.InteropServices.606hh9eikf.wasm"
    },
    {
      "hash": "sha256-IeA7pB0f/o3eZVGm+sIm8RKPcsD69THNJym/etwOWYI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.bp9v1jxw1s.wasm"
    },
    {
      "hash": "sha256-gk2n79PDu0EEuMzhjuC+ja2NGt3r87iH9g0JHrqTI64=",
      "url": "_framework/System.Runtime.Numerics.ulvabhoti2.wasm"
    },
    {
      "hash": "sha256-FdepB+eJ8fCVPeDPuaeeAzxnB85Oy4tycpE98rwy+Sw=",
      "url": "_framework/System.Runtime.vzyfiat9q1.wasm"
    },
    {
      "hash": "sha256-/xYxHC1kn+7sx+OOX07MJauwWNE3EH0XZVJ/L50Iam0=",
      "url": "_framework/System.Security.Cryptography.96mf7xwhxv.wasm"
    },
    {
      "hash": "sha256-m9sWG1pLMOm4f+5mpsgucim0tRkahlvrglfEC0qQR78=",
      "url": "_framework/System.Text.Encodings.Web.1t1de7t3v8.wasm"
    },
    {
      "hash": "sha256-3/ZAEIASf5m3rjziogYQVEWvFhCWpxgwDZ/lOB0xOWM=",
      "url": "_framework/System.Text.Json.14550wax69.wasm"
    },
    {
      "hash": "sha256-iIahuooyB2lxiH3INzFB4oRVNCiunA7QJk0eQDNV1NA=",
      "url": "_framework/System.Text.RegularExpressions.sv5fzugeiz.wasm"
    },
    {
      "hash": "sha256-JeXkfvDusZLoOt5kWMAz5dC8rQRJTwH5PMUZY3HJ80k=",
      "url": "_framework/System.Threading.jy4fgt3ud7.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-7Vfyzgo7EAl/P//bF3cSDDeOVMpCOFOPJr07Ug3kDmo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Ebk+Km0uqtdo/srKe0YcuUOlFykCcKVkBt03gTWt0aU=",
      "url": "_framework/dotnet.native.53ez3dx5uy.wasm"
    },
    {
      "hash": "sha256-nheeN4H7Js+avp9nd/sQxdaehbeEx3qriXjiZ3pSw6U=",
      "url": "_framework/dotnet.native.ykrnppwhq2.js"
    },
    {
      "hash": "sha256-cajUr4vA/MpLPWj3omULUOwEQw3i8CE2n8AmDheqWBM=",
      "url": "_framework/dotnet.runtime.peu2mfb29t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-rMZC+ElEtOAjNfQYIlNbF6cexzjV8oKvkYWTf6RVNbY=",
      "url": "_framework/ja/SiriusApp.resources.s8nci5syd8.wasm"
    },
    {
      "hash": "sha256-aHigjMpcsgpWr4gI5AuTuzr3ZgqvuvnoObyFsKhk7i0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-6XqLQZPD2i6BwDSe6KWMQuDVZ0PP8Npr5hisoPgn3JM=",
      "url": "index.html"
    },
    {
      "hash": "sha256-95YKwJjuG/IXZa9aqD3E1oMWpOAArXnkclsYVoDUNbY=",
      "url": "js/Bluetooth.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-AQ22XiIOtBS6dAaqEdPTKWhJE8IugxLr4cDRIy6MI4U=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-1ZSV+Gknh/l/LVwV+3SCjU+2H7Bmalr564qEYAiGwCo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-VdG6irgTI7di0FBrOQqYtHZ6uVNiNRpvoxgBMFCbm7c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-/AvtAxNRoM2K0/eFjOPYnLoI/VdiaCWXE35h3JtlWLo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-Vi38uvgZT2XvPPsOuY/ybd5Jnb4lvV4O9UQEk69CghE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-satyLJAPv02k0CWDXo3VLpeN/R+zSmG8oiSRmATu8Rw=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-etDaZIHnRUETHCB39uI0gJoQd7PB2KXRw1noOwq8BvM=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-ZeXWhyWXKqA4MpgnVjFEewtZQqYEiqR8fj67QNSDuZk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-NcUSHN7XIBvuYx66V4jYSLmBw+un5hImO8rawpemSxE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-JlOMcTyXOTWvHi4fyQUi5BY2svt9OFF7HMd3TWydrZc=",
      "url": "manifest.webmanifest"
    }
  ]
};
