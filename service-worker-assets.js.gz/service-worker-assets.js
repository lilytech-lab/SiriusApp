self.assetsManifest = {
  "version": "gXPVAEPo",
  "assets": [
    {
      "hash": "sha256-ZSJicRfSsO+B1xWmpXJ7ou81EIg418GnukAMFJRn3Bc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-EZNMO/azgG7IPa1IlFGwWmLhT64HPPCxhE0H6t+BOiM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-6TjAnwK83qx2u7jJRERCUpe4alFqntX4/M0Mk/AXYRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.p4cmqynr10.wasm"
    },
    {
      "hash": "sha256-N4f9FxLZ0MmQ+wOqFpIBsCTGFNE2DGqc5Xa9yEqinAs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dzlqjd09a5.wasm"
    },
    {
      "hash": "sha256-aSLzjUG9SRyTc6qmnRkw0fCu/QiARR+wEaE+AiYbioU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.z581my2xiy.wasm"
    },
    {
      "hash": "sha256-JLlAfosILy6R9B6V3zIqXQ/wmfeyC9ZnKVihs7liL7Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.o1m5okueg1.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-W2aRTwZoxGd2dpoERoF1PO4Y8vkQTdHrcHvghON6PzM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.z62dmpo713.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Gc7Oqk4/9MAtp0l7ESF6JgqIYusSvnbJXnLHUhPW9FY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5layk8frqd.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-720xjccNSC/ixI8d5toBVmd5GGEzQAIN2LMqBmflaJw=",
      "url": "_framework/Microsoft.Extensions.Options.1cu2gj5cau.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-xtQtSoK56ZLcZdr1TPIw4dex5O90dyRzRhWC9Coj9J8=",
      "url": "_framework/Microsoft.JSInterop.agnux60n3l.wasm"
    },
    {
      "hash": "sha256-XUJkLPs7rUEK96whaxjRwM1P+raTKceVeud0uUbIZYM=",
      "url": "_framework/MudBlazor.xjdb9om7fa.wasm"
    },
    {
      "hash": "sha256-jyWx4daKsjgoYGBiKqL3o/6BDur9WMOxwMO3tIlEv3A=",
      "url": "_framework/SiriusApp.bhaycgv4f0.wasm"
    },
    {
      "hash": "sha256-xJWTSLtKHK9HdU+yZ4dgUcTTA1iFgC+TSG1bUOcoHqU=",
      "url": "_framework/System.Collections.Concurrent.sa83p4stbu.wasm"
    },
    {
      "hash": "sha256-1aThh+81aX0gH+gT5RSfdnAfCspf0Jz1Q4h2xbkPLNY=",
      "url": "_framework/System.Collections.Immutable.1dw8fs7yz4.wasm"
    },
    {
      "hash": "sha256-HoUkKUGejd1OtWZ21VflCGLx/hugrfeDL7stJ2ztW1U=",
      "url": "_framework/System.Collections.usp2msd8zv.wasm"
    },
    {
      "hash": "sha256-JbHLj8j/f2l2Pa1qzHHO/RhVkjqVVkaQQxu1jwX79f0=",
      "url": "_framework/System.ComponentModel.Annotations.lkwdjajhg8.wasm"
    },
    {
      "hash": "sha256-N3oqk+07pwp3PuQa+kS3PGurE5Cb0CphN2CSc2jaW5Q=",
      "url": "_framework/System.ComponentModel.Primitives.j5ngxcb2zb.wasm"
    },
    {
      "hash": "sha256-6/imjLNsLXSkY9ycM3okm3qamzvBHg86eZepREkjv7c=",
      "url": "_framework/System.ComponentModel.TypeConverter.d6f1g9bet5.wasm"
    },
    {
      "hash": "sha256-R7ngh95V/nsqhrCHW2rk39aNArmqdfwpXE4RTI+u4Kk=",
      "url": "_framework/System.ComponentModel.fmqia21jk3.wasm"
    },
    {
      "hash": "sha256-76ZOedgIdxPwpPBx34425HxcNs0cFkD2FrqtUp6sTV8=",
      "url": "_framework/System.Console.18nadqjfwl.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-cZkwP5HyvfUGfX7x0n3xeaS5A+O/y1v19C57u2IhBkI=",
      "url": "_framework/System.Linq.10r3m2xz1k.wasm"
    },
    {
      "hash": "sha256-KIo4PAinHr33o/vDqVOEqrOkhv8uZj1LaVTMsDooR94=",
      "url": "_framework/System.Linq.Expressions.kp0hg2g0b8.wasm"
    },
    {
      "hash": "sha256-wy2EU9j5x+FTuhiwP8UqFcKkiwVBxA9lq45vLjqQo6w=",
      "url": "_framework/System.Memory.z4lrm545w5.wasm"
    },
    {
      "hash": "sha256-4QI1wOCtQSq/83+bNlWTBmCg1wggLcCDsXLIzGRPAJA=",
      "url": "_framework/System.Net.Http.jvborohthi.wasm"
    },
    {
      "hash": "sha256-KH4CVAPEDPjgX5PXvYBbhlTzNNL/Own3ELMwYvJ+tzM=",
      "url": "_framework/System.Net.Primitives.kdvc0a7ikr.wasm"
    },
    {
      "hash": "sha256-5c1U4CNNrpvP/GiP0JMUsKzUy+nTJxL/oavjEMANvQA=",
      "url": "_framework/System.ObjectModel.fjm8uc0elu.wasm"
    },
    {
      "hash": "sha256-Oym4N4N4Jd2KsJbjzwoLXPppdorgGWzoIy6dm7OCkkM=",
      "url": "_framework/System.Private.CoreLib.h9vq2lws9i.wasm"
    },
    {
      "hash": "sha256-9VwWxgJlBGy/6rPcNOk68ZpFk1CG10AMqsy+yv1A//Y=",
      "url": "_framework/System.Private.Uri.vjgxthzmtg.wasm"
    },
    {
      "hash": "sha256-uTkW+krOAnCyD3XIzG65toF4ZaWZzXkVZPVwvItmxng=",
      "url": "_framework/System.Runtime.70ofnm9ekt.wasm"
    },
    {
      "hash": "sha256-pLr/Ys4hCRUIbnJOTabUttdOQTgaKzJPRmT6/do1uGg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.83zwdhfd7p.wasm"
    },
    {
      "hash": "sha256-iEhPTaQJ4jCeoj1L0EhagDRNRmxK7I6h9LVyXL2fxLk=",
      "url": "_framework/System.Runtime.InteropServices.gmhlr8xdyr.wasm"
    },
    {
      "hash": "sha256-PVCrhDn4h1OgqMGUhEs25nlp1YW7mMfPoEgZxltnMoo=",
      "url": "_framework/System.Text.Encodings.Web.n7nth9auq4.wasm"
    },
    {
      "hash": "sha256-C5Iroe1Eao8ap7KuqMDCWEt8iJwJ1SND49M++grENpc=",
      "url": "_framework/System.Text.Json.b47cv9yiwm.wasm"
    },
    {
      "hash": "sha256-p4r+hs4jgtmFZsgNMgfZB1XAyK1YyqVqjw6N3KiyRZI=",
      "url": "_framework/System.Text.RegularExpressions.xm2gsqk2m5.wasm"
    },
    {
      "hash": "sha256-vTZNFSZOWDwpEr2E67SJDUQKO29mWQqVcR0XWYnj3ZQ=",
      "url": "_framework/System.Threading.1zdcxdxxda.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-sO3ngHNpovheEQHCUjHqh2f/xih/x3055FG5KzblEZA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HHqsNtcX76Ik012KVAobmCLooIZ2znhTFCqfijzEdi0=",
      "url": "_framework/dotnet.native.swgexbmoy7.wasm"
    },
    {
      "hash": "sha256-/ifJokfQvXKw1hEziCkYR9SOJIKSdGG/UKw5gbLWrj0=",
      "url": "_framework/dotnet.native.uhsveqo9bs.js"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-aHigjMpcsgpWr4gI5AuTuzr3ZgqvuvnoObyFsKhk7i0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-5iBF2dgl+I6U2pOfPJa1YO9QbJHaRI4vVqRLuwrsgZk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VQ7ez1YJaSu+41C4kSSLB0ogxSqUMzQeUbNlb9GUD3Q=",
      "url": "js/Bluetooth.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-AQ22XiIOtBS6dAaqEdPTKWhJE8IugxLr4cDRIy6MI4U=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-1ZSV+Gknh/l/LVwV+3SCjU+2H7Bmalr564qEYAiGwCo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-VdG6irgTI7di0FBrOQqYtHZ6uVNiNRpvoxgBMFCbm7c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-/AvtAxNRoM2K0/eFjOPYnLoI/VdiaCWXE35h3JtlWLo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-Vi38uvgZT2XvPPsOuY/ybd5Jnb4lvV4O9UQEk69CghE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-satyLJAPv02k0CWDXo3VLpeN/R+zSmG8oiSRmATu8Rw=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-etDaZIHnRUETHCB39uI0gJoQd7PB2KXRw1noOwq8BvM=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-ZeXWhyWXKqA4MpgnVjFEewtZQqYEiqR8fj67QNSDuZk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-NcUSHN7XIBvuYx66V4jYSLmBw+un5hImO8rawpemSxE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-JlOMcTyXOTWvHi4fyQUi5BY2svt9OFF7HMd3TWydrZc=",
      "url": "manifest.webmanifest"
    }
  ]
};
