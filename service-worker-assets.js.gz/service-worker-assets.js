self.assetsManifest = {
  "version": "ehKlwh/0",
  "assets": [
    {
      "hash": "sha256-ZSJicRfSsO+B1xWmpXJ7ou81EIg418GnukAMFJRn3Bc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-EZNMO/azgG7IPa1IlFGwWmLhT64HPPCxhE0H6t+BOiM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-6TjAnwK83qx2u7jJRERCUpe4alFqntX4/M0Mk/AXYRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.p4cmqynr10.wasm"
    },
    {
      "hash": "sha256-N4f9FxLZ0MmQ+wOqFpIBsCTGFNE2DGqc5Xa9yEqinAs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dzlqjd09a5.wasm"
    },
    {
      "hash": "sha256-aSLzjUG9SRyTc6qmnRkw0fCu/QiARR+wEaE+AiYbioU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.z581my2xiy.wasm"
    },
    {
      "hash": "sha256-JLlAfosILy6R9B6V3zIqXQ/wmfeyC9ZnKVihs7liL7Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.o1m5okueg1.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-W2aRTwZoxGd2dpoERoF1PO4Y8vkQTdHrcHvghON6PzM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.z62dmpo713.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Gc7Oqk4/9MAtp0l7ESF6JgqIYusSvnbJXnLHUhPW9FY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5layk8frqd.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-720xjccNSC/ixI8d5toBVmd5GGEzQAIN2LMqBmflaJw=",
      "url": "_framework/Microsoft.Extensions.Options.1cu2gj5cau.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-xtQtSoK56ZLcZdr1TPIw4dex5O90dyRzRhWC9Coj9J8=",
      "url": "_framework/Microsoft.JSInterop.agnux60n3l.wasm"
    },
    {
      "hash": "sha256-XUJkLPs7rUEK96whaxjRwM1P+raTKceVeud0uUbIZYM=",
      "url": "_framework/MudBlazor.xjdb9om7fa.wasm"
    },
    {
      "hash": "sha256-4mhjA2p4TAEFPz9uQVrdIpSVo0Qnzk57pSh5bDCu/3o=",
      "url": "_framework/SiriusApp.qi4o8198lj.wasm"
    },
    {
      "hash": "sha256-02ggB0ZBjTHGDP6vfyxM1wgpQhq96WVOIlaWM3ywif8=",
      "url": "_framework/System.Collections.Concurrent.xb45u9t2a0.wasm"
    },
    {
      "hash": "sha256-jVMElT4Dv5+ODKXbya+BHVwXNU0K+AE4iPSNYvfLEXc=",
      "url": "_framework/System.Collections.Immutable.f1ce80ns32.wasm"
    },
    {
      "hash": "sha256-RmlHQQvH4zq6AUoG61F8tLHdyFUBFyiMSz7C1d6lQLs=",
      "url": "_framework/System.Collections.q0q85v649n.wasm"
    },
    {
      "hash": "sha256-5tcDtk3K3D5zAl1cAOjcurrfbjH3qi+GUPwpyYtFVZ8=",
      "url": "_framework/System.ComponentModel.Annotations.msibo7lbpq.wasm"
    },
    {
      "hash": "sha256-orCCA0Gpglh7d+LI84d5QT5fUC3osBOVmI5P39yUKLo=",
      "url": "_framework/System.ComponentModel.Primitives.20m1nptdcc.wasm"
    },
    {
      "hash": "sha256-O8w7ZkxUdozU5Tvi0fYnfE49d/2WRNufXxkb/lLlI4g=",
      "url": "_framework/System.ComponentModel.TypeConverter.lo585ct37u.wasm"
    },
    {
      "hash": "sha256-QWVyYfFMyQkEJcXzgiXaAF6HzJbM9vtnP9Ds9H24kU8=",
      "url": "_framework/System.ComponentModel.tpqwi9wclf.wasm"
    },
    {
      "hash": "sha256-plQQzJOmpVQb2ntN5JmdSfRnqjC5MVsXPFCZRtce4bI=",
      "url": "_framework/System.Console.i1ng07chjs.wasm"
    },
    {
      "hash": "sha256-A/zbBw0DrouhwRThvr8F1IcKa5ApGW5BE01HoHB7igA=",
      "url": "_framework/System.IO.Pipelines.twix2pm6u4.wasm"
    },
    {
      "hash": "sha256-isrk6o8uhKsSFt+fnvxsfD4k4IPBhN05kKeByV/ga68=",
      "url": "_framework/System.Linq.Expressions.mxlecu6ppc.wasm"
    },
    {
      "hash": "sha256-uDzqiQnmWWOEv6MhCP8t6h4qV2POd5uY1rWP/CXAyhs=",
      "url": "_framework/System.Linq.cj9scyht39.wasm"
    },
    {
      "hash": "sha256-EDxUNMKEEeOndsGmiUq3La1rqwIajfhplrzQ/MiASco=",
      "url": "_framework/System.Memory.00zfd6eyoh.wasm"
    },
    {
      "hash": "sha256-DD73DIECIdjHNDQjfDF/DnQBAZ7UT128am2WWEpUB4w=",
      "url": "_framework/System.Net.Http.4sg4k4vifm.wasm"
    },
    {
      "hash": "sha256-a4dB30YFNq/SY/LiMHqwVY80wc9IhWkxSr0potvkLog=",
      "url": "_framework/System.Net.Primitives.p74tuosjpr.wasm"
    },
    {
      "hash": "sha256-Exa4GUm2+I9efrMKawgsJk+f/El9mqPlJIgPNbeDqAU=",
      "url": "_framework/System.ObjectModel.ra98xx1pm3.wasm"
    },
    {
      "hash": "sha256-FjquXcgwTw5KTQImbN9bu//ydN6XqrCeRUazWFQxUm8=",
      "url": "_framework/System.Private.CoreLib.6wlp7uidpu.wasm"
    },
    {
      "hash": "sha256-Xb2IJXSoULDRisJjnOfcS4+aguQpx0fjVRoUzhSNyiI=",
      "url": "_framework/System.Private.Uri.rexy1t3kee.wasm"
    },
    {
      "hash": "sha256-51U1Jop+TFZlL27Bx6Je5B5J9n00+dyKolwuS3qVOUA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.v6n6nxwok6.wasm"
    },
    {
      "hash": "sha256-6LMcFkmT563qL09jz3igCcpto0IrJybPowVQwOKHUEE=",
      "url": "_framework/System.Runtime.InteropServices.k51x88yyx5.wasm"
    },
    {
      "hash": "sha256-/mMTJ82rBNnN2Ss2hwWLtoR3Gh8uR8y7FAeiCs1HIGE=",
      "url": "_framework/System.Runtime.u1c0nmhjar.wasm"
    },
    {
      "hash": "sha256-KqqWRjKnEB6AfDVf3rm0/MCd7SXbSGKyKpcY/+zEjSA=",
      "url": "_framework/System.Text.Encodings.Web.6kgc70ln9c.wasm"
    },
    {
      "hash": "sha256-y9vl1QwNBNp+HBENGFu4vRuJtEZ/pz7N9WBscrQn5Y8=",
      "url": "_framework/System.Text.Json.vjstyl13kv.wasm"
    },
    {
      "hash": "sha256-rIEltnMg0klFQJ1l1ErW//KzspxYJOpfpUSyRGhpUQI=",
      "url": "_framework/System.Text.RegularExpressions.8d5mlis5fs.wasm"
    },
    {
      "hash": "sha256-EU5VY1c/ZUg7jsByRpOZAr2Hyy1x2Tt8TumHzdsjnGE=",
      "url": "_framework/System.Threading.dl9ilaz6vs.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-/RKjScys8kgm8y56bW4rrgtGMuYJgehHgn+eNFBCRVQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-WIUiy49hHQ3kOAtRdCtUzm3Yg5BnOqCC+Q+kri9Fi1g=",
      "url": "_framework/dotnet.native.8o8n7iomrf.js"
    },
    {
      "hash": "sha256-bvHGVH9zAMOjdIvgvRKP4Bg793vWpedEYSWg32uUr3o=",
      "url": "_framework/dotnet.native.aep4lch3d1.wasm"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-aHigjMpcsgpWr4gI5AuTuzr3ZgqvuvnoObyFsKhk7i0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-iNViCJhbKZazZa18mu/Xd4YOXe6BFy/t59lpcwii6sE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VQ7ez1YJaSu+41C4kSSLB0ogxSqUMzQeUbNlb9GUD3Q=",
      "url": "js/Bluetooth.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-AQ22XiIOtBS6dAaqEdPTKWhJE8IugxLr4cDRIy6MI4U=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-1ZSV+Gknh/l/LVwV+3SCjU+2H7Bmalr564qEYAiGwCo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-VdG6irgTI7di0FBrOQqYtHZ6uVNiNRpvoxgBMFCbm7c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-/AvtAxNRoM2K0/eFjOPYnLoI/VdiaCWXE35h3JtlWLo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-Vi38uvgZT2XvPPsOuY/ybd5Jnb4lvV4O9UQEk69CghE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-satyLJAPv02k0CWDXo3VLpeN/R+zSmG8oiSRmATu8Rw=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-etDaZIHnRUETHCB39uI0gJoQd7PB2KXRw1noOwq8BvM=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-ZeXWhyWXKqA4MpgnVjFEewtZQqYEiqR8fj67QNSDuZk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-NcUSHN7XIBvuYx66V4jYSLmBw+un5hImO8rawpemSxE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-JlOMcTyXOTWvHi4fyQUi5BY2svt9OFF7HMd3TWydrZc=",
      "url": "manifest.webmanifest"
    }
  ]
};
